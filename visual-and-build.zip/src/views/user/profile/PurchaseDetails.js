import React from "react";

const PurchaseDetails = () => {
  return <div>PurchaseDetails</div>;
};

export default PurchaseDetails;
