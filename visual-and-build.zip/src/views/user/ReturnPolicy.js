import React from "react";

const ReturnPolicy = () => {
  return <div>ReturnPolicy</div>;
};

export default ReturnPolicy;
