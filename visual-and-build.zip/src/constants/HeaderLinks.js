export const navLinks = [
  {
    id: 3,
    title: "Shop All",
    link: "/search",
  },
  {
    id: 1,
    title: "Group Buy",
    link: "/group-buy",
  },
  {
    id: 1,
    title: "Instabuild",
    link: "/search?instabuild=true",
  },
  {
    id: 2,
    title: "Blogs",
    link: "/blogs",
  },
];
